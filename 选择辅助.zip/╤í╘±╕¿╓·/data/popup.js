﻿document.addEventListener('DOMContentLoaded', function() {

				document.getElementById('regstring').value = localStorage.getItem("regstring");

});

document.getElementById('savesetting').addEventListener('click', function() {

		var regstring = document.getElementById('regstring').value;

	
			chrome.runtime.sendMessage({greeting:"regstring",string:regstring},function(r){
				if(r=="isauthed"){
										localStorage.setItem("regstring",regstring);

				}else{
					alert('无效注册码');
				}
			});
			


});



